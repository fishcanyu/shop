import java.util.Scanner;
import java.util.Arrays;

public class dtp {
    public static void main(String[] args) {
        System.out.println("猜數字遊戲!");
        int[] rand = new int[4];
        for(int i=0; i<rand.length; i++)
        {
            int r = 0;
            r = (int)(Math.random()*10);
             rand[i] = r; 
        }
        System.out.println(Arrays.toString(rand));
        Scanner scanner = new Scanner(System.in);
        System.out.print("請輸入一個數字，且數字不得重複: ");
        int b = scanner.nextInt();
        System.out.printf("你輸入的數字為: %d\n", b);
        scanner.close();

        int aa = 0;
        int bb = 0; // 設立AB
        for (int i = 3; i >= 0 ; i--) {
            int a = rand[i];
            System.out.printf("a為: %d\n", a);
            int digit = b % 10; // 取得輸入數字的最後一位數字
            b /= 10; // 移除輸入數字的最後一位數字
            if (a == digit) 
            {
                aa++;
            }
            for (int j = 0; j < 4; j++) 
            {
                int bbNumber = rand[j];
                if (bbNumber == digit && i != j) {
                    bb++;
                }
            }
        }
        System.out.printf("結果: %dA%dB\n", aa, bb);
    }
}